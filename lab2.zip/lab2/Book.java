package lab2;

public class Book extends WrittenItem{
	
	public Book()
	{
		super();
	}
	
	
	public Book(int itemIdNum, int itemCopies, String itemTitle, String author) {
		super(itemIdNum, itemCopies, itemTitle, author);
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Book [checkIn=" + checkIn + ", checkOut=" + checkOut + "]";
	}


	

}
