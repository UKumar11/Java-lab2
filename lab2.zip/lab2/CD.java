package lab2;

public class CD extends MediaItem{
	
	private String cdArtist,cdGenre;

	public CD(int itemIdNum, int itemCopies, String itemTitle, int runtime, String cdArtist, String cdGenre) {
		super(itemIdNum, itemCopies, itemTitle, runtime);
		this.cdArtist = cdArtist;
		this.cdGenre = cdGenre;
	}
	
	public CD()
	{
		super();
	}
	

	public String getCdArtist() {
		return cdArtist;
	}

	public void setCdArtist(String cdArtist) {
		this.cdArtist = cdArtist;
	}

	public String getCdGenre() {
		return cdGenre;
	}

	public void setCdGenre(String cdGenre) {
		this.cdGenre = cdGenre;
	}
	
	

}
