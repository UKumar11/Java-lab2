package lab2;

public class JournalPaper extends WrittenItem {
	
	private int yearpublished;
	
	
	
	public JournalPaper(int itemIdNum, int itemCopies, String itemTitle, String author, int yearpublished) {
		super(itemIdNum, itemCopies, itemTitle, author);
		this.yearpublished = yearpublished;
	}

	public JournalPaper()
	{
		super();
		
	}

	public int getYearpublished() {
		return yearpublished;
	}

	public void setYearpublished(int yearpublished) {
		this.yearpublished = yearpublished;
	}


}
