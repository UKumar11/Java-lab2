package lab2;

public class Video extends MediaItem{
	
	
	private String videoDirector,videoGenre;
	private int yearReleased;
	public Video(int itemIdNum, int itemCopies, String itemTitle, int runtime, String director, String genre,
			int yearReleased) {
		super(itemIdNum, itemCopies, itemTitle, runtime);
		this.videoDirector = director;
		this.videoGenre = genre;
		this.yearReleased = yearReleased;
	}
	
	
	public Video()
	{
		super();
	}
	
	public String getDirector() {
		return videoDirector;
	}
	public void setDirector(String director) {
		this.videoDirector = director;
	}
	public String getGenre() {
		return videoGenre;
	}
	public void setGenre(String genre) {
		this.videoGenre = genre;
	}
	public int getYearReleased() {
		return yearReleased;
	}
	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}
	
	
	
	
}
