package lab2;

public abstract class MediaItem extends Item{
	
	private int runtime;

	public MediaItem(int itemIdNum, int itemCopies, String itemTitle, int runtime) {
		super(itemIdNum, itemCopies, itemTitle);
		this.runtime = runtime;
	}

	public MediaItem()
	{
		super();
	}
	
	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
}
