package lab2;

public abstract class Item {
	
	private int itemIdNum,itemCopies;
	private String itemTitle;
	public int checkIn,checkOut;
	public int getItemIdNum() {
		return itemIdNum;
	}
	public void setItemIdNum(int itemIdNum) {
		this.itemIdNum = itemIdNum;
	}
	public int getItemCopies() {
		return itemCopies;
	}
	public void setItemCopies(int itemCopies) {
		this.itemCopies = itemCopies;
	}
	public String getItemTitle() {
		return itemTitle;
	}
	public void setItemTitle(String itemTitle) {
		this.itemTitle = itemTitle;
	}
	public Item(int itemIdNum, int itemCopies, String itemTitle) {
		super();
		this.itemIdNum = itemIdNum;
		this.itemCopies = itemCopies;
		this.itemTitle = itemTitle;
	}
	public Item() {
		super();
		
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemCopies;
		result = prime * result + itemIdNum;
		result = prime * result + ((itemTitle == null) ? 0 : itemTitle.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (itemCopies != other.itemCopies)
			return false;
		if (itemIdNum != other.itemIdNum)
			return false;
		if (itemTitle == null) {
			if (other.itemTitle != null)
				return false;
		} else if (!itemTitle.equals(other.itemTitle))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Item [itemIdNum=" + itemIdNum + ", itemCopies=" + itemCopies + ", itemTitle=" + itemTitle + "]";
	}
	
	public void addItem(int itemIdNum, int itemCopies, String itemTitle)
	{
		this.itemIdNum = itemIdNum;
		this.itemCopies = itemCopies;
		this.itemTitle = itemTitle;
	}
	
	public  void checkIn(int day)
	{
		this.checkIn = day;
	}
	
	public void checkOut(int day)
	{
		this.checkOut = day;
	}

}
