package lab2;

public class Operations {

	public static void main(String[] args) {
	System.out.println("\n============Operations on Book class and its super Classs============");
	
	System.out.println("\nUsing Constructor\n");
	Book b2 = new Book(2,20,"C","Ujjwal");
	System.out.println(" Book Id Number : "+b2.getItemIdNum());
	System.out.println(" Book Title : "+b2.getItemTitle());
	System.out.println(" Book Author : "+b2.getAuthor());
	System.out.println(" Book Nmber of Copies : "+b2.getItemCopies());
	
	System.out.println("\nUsing Setters\n");
	Book b1 = new Book();
	b1.setItemIdNum(1);
	b1.setItemCopies(10);
	b1.setItemTitle("Java 8");
	b1.setAuthor("Jeevan K");
	
	System.out.println(" Book Id Number : "+b1.getItemIdNum());
	System.out.println(" Book Title : "+b1.getItemTitle());
	System.out.println(" Book Author : "+b1.getAuthor());
	System.out.println(" Book Nmber of Copies : "+b1.getItemCopies());
	
	System.out.println("\n============Operations on Journal Paper class and its super Classs============");
	System.out.println("\nUsing Constructor\n");
	JournalPaper j1 = new JournalPaper(11,30,"C++","Karthik",2001);
	System.out.println(" JournalPaper Id Number : "+j1.getItemIdNum());
	System.out.println(" JournalPaper Title : "+j1.getItemTitle());
	System.out.println(" JournalPaper Author : "+j1.getAuthor());
	System.out.println(" JournalPaper Published Year : "+j1.getYearpublished());
	System.out.println(" JournalPaper Nmber of Copies : "+j1.getItemCopies());
	
	System.out.println("\nUsing Setters\n");
	JournalPaper j2 = new JournalPaper();
	j2.setItemIdNum(12);
	j2.setItemCopies(100);
	j2.setItemTitle("C#");
	j2.setAuthor("Bhawik");
	j2.setYearpublished(2000);
	
	System.out.println(" JournalPaper Id Number : "+j2.getItemIdNum());
	System.out.println(" JournalPaper Title : "+j2.getItemTitle());
	System.out.println(" JournalPaper Author : "+j2.getAuthor());
	System.out.println(" JournalPaper Published Year : "+j2.getYearpublished());
	System.out.println(" JournalPaper Nmber of Copies : "+j2.getItemCopies());
	
	
	System.out.println("\n============Operations on Video class and its super Classs============");
	System.out.println("\nUsing Constructor\n");
	Video v1 = new Video(111,40,"Taken",190,"Karthik","Action",2011);
	System.out.println(" Video Id Number : "+v1.getItemIdNum());
	System.out.println(" Video Title : "+v1.getItemTitle());
	System.out.println(" Video genre : "+v1.getGenre());
	System.out.println(" Video Runtime : "+v1.getRuntime());
	System.out.println(" Video Director : "+v1.getDirector());
	System.out.println(" Video Released Year : "+v1.getYearReleased());
	System.out.println(" Video Number of Copies : "+v1.getItemCopies());
	
	System.out.println("\nUsing Setters\n");
	Video v2 = new Video();
	v2.setItemIdNum(112);
	v2.setItemCopies(100);
	v2.setItemTitle("Gangajal");
	v2.setDirector("Bhawik");
	v2.setYearReleased(1995);
	v2.setRuntime(200);
	v2.setGenre("Drama");
	
	System.out.println(" Video Id Number : "+v2.getItemIdNum());
	System.out.println(" Video Title : "+v2.getItemTitle());
	System.out.println(" Video genre : "+v2.getGenre());
	System.out.println(" Video Runtime : "+v2.getRuntime());
	System.out.println(" Video Director : "+v2.getDirector());
	System.out.println(" Video Released Year : "+v2.getYearReleased());
	System.out.println(" Video Number of Copies : "+v2.getItemCopies());
	
	System.out.println("\n============Operations on CD class and its super Classs============");
	System.out.println("\nUsing Constructor\n");
	CD c1 = new CD(111,40,"Mummy",150,"jack","Horror");
	System.out.println(" CD Id Number : "+c1.getItemIdNum());
	System.out.println(" CD Title : "+c1.getItemTitle());
	System.out.println(" CD genre : "+c1.getCdGenre());
	System.out.println(" CD Runtime : "+c1.getRuntime());
	System.out.println(" CD Artist : "+c1.getCdArtist());
	System.out.println(" CD Number of Copies : "+c1.getItemCopies());
	
	System.out.println("\nUsing Setters\n");
	CD c2 = new CD();
	c2.setItemIdNum(112);
	c2.setItemCopies(100);
	c2.setItemTitle("Grown Ups");
	c2.setCdArtist("Andy Samberg");
	c2.setRuntime(200);
	c2.setCdGenre("Comedy");
	
	System.out.println(" CD Id Number : "+c2.getItemIdNum());
	System.out.println(" CD Title : "+c2.getItemTitle());
	System.out.println(" CD genre : "+c2.getCdGenre());
	System.out.println(" CD Runtime : "+c2.getRuntime());
	System.out.println(" CD Artist : "+c2.getCdArtist());
	System.out.println(" CD Number of Copies : "+c2.getItemCopies());
	
	
	
	
	}

}
